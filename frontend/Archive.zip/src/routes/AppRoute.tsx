const AppRoute = () => {
  return <div>AppRoute</div>;
};

export default AppRoute;
